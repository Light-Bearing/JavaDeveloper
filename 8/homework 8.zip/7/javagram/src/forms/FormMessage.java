package forms;

import javax.swing.*;

public class FormMessage {
    public JPanel getRootPanel() {
        return panelMain;
    }

    private JPanel panelMain;
    private JButton buttonAddContact;
    private JButton buttonDeleteContact;
    private JList listContact;
    private JButton buttonEditContact;
    private JButton buttonSend;
    private JTextField textSends;
    private JButton buttonSettings;
    private JTextField textSerche;
}

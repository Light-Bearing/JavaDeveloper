package org.skillbox.lesson3;

import org.javagram.TelegramApiBridge;
import org.javagram.response.AuthAuthorization;
import org.javagram.response.AuthCheckedPhone;
import org.javagram.response.AuthSentCode;
import org.javagram.response.object.User;
import org.telegram.api.TLAbsUser;
import org.telegram.api.auth.TLAuthorization;
import org.telegram.api.requests.TLRequestAuthSignIn;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));


        TelegramApiBridge bridge = new TelegramApiBridge("149.154.167.50:443", 718505, "432dbe82e512be4a98b3cb8a835179c6");
        System.out.println("Please, type phone number:");
        String phoneNumber = reader.readLine().trim();
        bridge.authCheckPhone(phoneNumber);
        bridge.authSendCode(phoneNumber);
        AuthAuthorization authSignIn = bridge.authSignIn(reader.readLine().trim());
        User user = authSignIn.getUser();
        System.out.println("FirstName: " + user.getFirstName() + ", LastName: " + user.getLastName() + ", Phone: " + user.getPhone());

    }
}
